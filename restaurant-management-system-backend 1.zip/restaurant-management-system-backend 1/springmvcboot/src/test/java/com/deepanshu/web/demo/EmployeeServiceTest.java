package com.deepanshu.web.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.intThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.deepanshu.web.demo.model.Employee;
import com.deepanshu.web.demo.repository.EmployeeRepository;
import com.deepanshu.web.demo.service.EmployeeServiceImpl;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTest {

	@Mock
	private EmployeeRepository employeeRepository;
	
	@InjectMocks
	private EmployeeServiceImpl employeeServiceImpl;
	
	
	private Employee employee;
	
	
    @BeforeEach
    public void setup(){
        //employeeRepository = Mockito.mock(EmployeeRepository.class);
        //employeeService = new EmployeeServiceImpl(employeeRepository);
        employee = Employee.builder()
           .id(1)
           .employeename("Deepanshu")
           .employeedesgn("CEO")
           .employeephoneno("6289833582")
           .employeeemailid("deep@gmail.com")
           .build();
           
    }
    
    // JUnit test for addEmployee method
    @DisplayName("JUnit test for addEmployee method")
    @Test
    public void givenEmployeeObject_whenSaveEmployee_thenReturnEmployeeObject(){
        // given - precondition or setup

        when(employeeRepository.save(employee)).thenReturn(employee);

        System.out.println(employeeRepository);
        System.out.println(employeeServiceImpl);

        // when -  action or the behaviour that we are going test
        Employee savedEmployee = employeeServiceImpl.AddEmployee(employee);

        System.out.println(savedEmployee);
        // then - verify the output
        assertThat(savedEmployee).isNotNull();
    }
    
    @DisplayName("JUnit test for getEmployeeById method")
    @Test
    public void givenEmployeeId_whenGetEmployeeById_thenReturnEmployeeObject(){
        // given
        when(employeeRepository.findById(1)).thenReturn(Optional.of(employee));

        // when
        Employee savedEmployee = employeeServiceImpl.getEmployeeById(employee.getId());

        // then
        assertThat(savedEmployee).isNotNull();

    }
    
    
    @DisplayName("JUnit test for getAllEmployee method")
    @Test
    public void givenEmployeesList_whenGetAllEmployees_thenReturnEmployeesList(){
        // given - precondition or setup

        Employee employee1 = Employee.builder()
                .id(2)
                .employeename("Rahul")
                .employeedesgn("Waiter")
                .employeephoneno("tony@gmail.com")
                .employeeemailid("rahul@gmail.com")
                .build();

        when(employeeRepository.findAll()).thenReturn(List.of(employee,employee1));

        // when -  action or the behaviour that we are going test
        List<Employee> employeeList = employeeServiceImpl.getAllEmployee();

        // then - verify the output
        assertThat(employeeList).isNotNull();
        assertThat(employeeList.size()).isEqualTo(2);
    }
    
    @DisplayName("JUnit test for updateEmployee method")
    @Test
    public void givenEmployeeObject_whenUpdateEmployee_thenReturnUpdatedEmployee(){
        // given - precondition or setup
    	Employee existingEmployee = new Employee();
        existingEmployee.setId(1);
        existingEmployee.setEmployeename("John");
        existingEmployee.setEmployeedesgn("Developer");
        existingEmployee.setEmployeeemailid("john@example.com");
        existingEmployee.setEmployeephoneno("1234567890");

        Employee newEmployee = new Employee();
        newEmployee.setEmployeename("Jane");
        newEmployee.setEmployeedesgn("Developer");
        newEmployee.setEmployeeemailid("jane@example.com");
        newEmployee.setEmployeephoneno("0987654321");

        when(employeeRepository.findById(any(Integer.class))).thenReturn(Optional.of(existingEmployee));
        when(employeeRepository.save(any(Employee.class))).thenReturn(newEmployee);

        Employee updatedEmployee = employeeServiceImpl.updateEmployee(1, newEmployee);

        assertEquals("Jane", updatedEmployee.getEmployeename());
        assertEquals("Developer", updatedEmployee.getEmployeedesgn());
        assertEquals("jane@example.com", updatedEmployee.getEmployeeemailid());
        assertEquals("0987654321", updatedEmployee.getEmployeephoneno());
    }

    
    @DisplayName("JUnit test for deleteEmployee method")
    @Test
    public void givenEmployeeId_whenDeleteEmployee_thenNothing(){
        // given - precondition or setup
        int employeeId = 1;

        doNothing().when(employeeRepository).deleteById(employeeId);

        // when -  action or the behaviour that we are going test
        employeeServiceImpl.deleteEmployee(employeeId);

        // then - verify the output
        verify(employeeRepository, times(1)).deleteById(employeeId);
    }
    
    
    
}
