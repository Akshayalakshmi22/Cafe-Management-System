package com.deepanshu.web.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deepanshu.web.demo.customException.ResourceNotFoundException;
import com.deepanshu.web.demo.model.User;
import com.deepanshu.web.demo.repository.UseritemRepository;

import jakarta.validation.Valid;

@Service
public class UserItemServiec{
 
	@Autowired

	private UseritemRepository repo;
 
	public List<User> findAllValues() throws Exception {

		List<User> logList = repo.findAll();

		if (logList.isEmpty()) {

			throw new Exception("User not found");

		}

		return logList;

	}
 
	public User findOne(Long id) throws Exception {

		Optional<User> log = repo.findById(id);

		try {

			User login = log.get();

			return login;

		} catch (Exception e) {

			throw new Exception("Id:" + id + " does not exists");

		}

	}
 
	public User save(@Valid User ob) throws Exception {

		if (ob.getId() == null) { // it's mean user id not provided so create new user in

			List<User> logList = findAllValues(); // taking all list values

			for (User i : logList) {

				if (i.getEmail().equals(ob.getEmail())) {

					throw new Exception("user already registered"); // it mean user already registered

				}

			}

		

			ob.setRole("User");

			User log = repo.save(ob);

			return log;

		} else { // it's mean user id provided

			Long id = ob.getId();

			findOne(id);  // checking valid id

			return repo.save(ob);

		}
 
	}
 
	public String delete(Long idd) throws Exception {
		try {
			repo.findById(idd).get();
			repo.deleteById(idd);
			return "Record removed Successfully";
		} catch (Exception e) {
			throw new Exception("Id:" + idd + " does not exists");
		}
	}
 
	public User update(User ob) throws Exception {
		Long id = ob.getId();
		findOne(id);       // checking valid id
		ob.setRole("User");
		return repo.save(ob);
	}
 

 
	public User logIn(@Valid String email, @Valid String pass) throws Exception {

		List<User> logList = findAllValues(); // taking all list values

		for (User i : logList) {

			if (i.getEmail().equals(email) && i.getPassword().equals(pass)) {

				return i;

			}

		}

		throw new Exception("Either passowrd or email is incorrect");

	}
 
}

