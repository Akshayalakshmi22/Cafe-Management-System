package com.deepanshu.web.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="Employees")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	
	private String employeename;
	
	private String employeedesgn;
	
	@Size(min = 10,max = 10,message = "Please provide a proper phone-no!!")
	private String employeephoneno;
	
	@Email(message = "Please provide a proper email!!")
	private String employeeemailid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmployeename() {
		return employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public String getEmployeedesgn() {
		return employeedesgn;
	}

	public void setEmployeedesgn(String employeedesgn) {
		this.employeedesgn = employeedesgn;
	}

	public String getEmployeephoneno() {
		return employeephoneno;
	}

	public void setEmployeephoneno(String employeephoneno) {
		this.employeephoneno = employeephoneno;
	}

	public String getEmployeeemailid() {
		return employeeemailid;
	}

	public void setEmployeeemailid(String employeeemailid) {
		this.employeeemailid = employeeemailid;
	}

	public Employee(int id, String employeename, String employeedesgn, String employeephoneno, String employeeemailid) {
		super();
		this.id = id;
		this.employeename = employeename;
		this.employeedesgn = employeedesgn;
		this.employeephoneno = employeephoneno;
		this.employeeemailid = employeeemailid;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static class EmployeeBuilder
	 {
		private int id;
		private String employeename;
		private String employeedesgn;
		private String employeephoneno;
		private String employeeemailid;
		
	
        
	
	 @Override
		public String toString() {
			return "Employee.EmployeeBuilder(id="+this.id+",employeename="+this.employeename+",employeedesgn="+this.employeedesgn+",employeephoneno="+this.employeephoneno+",employeeemailid="+this.employeeemailid+")";
			
		}

	public Employee build()
	 {
	 	return new Employee(this.id, this.employeename, this.employeedesgn, this.employeephoneno, this.employeeemailid);
	 }
	
	 public EmployeeBuilder id(int id)
	 {
	 this.id = id;
	 return this;
	 }
	
	 public EmployeeBuilder employeename(String employeename)
	 {
	 	this.employeename = employeename;
	 	return this;
	 }
	
	 public EmployeeBuilder employeedesgn(String employeedesgn)
	 {
	 	this.employeedesgn = employeedesgn;
	 	return this;
	 }
	
	 public EmployeeBuilder employeephoneno(String employeephoneno)
	 {
	 	this.employeephoneno = employeephoneno;
	 	return this;
	 }
	
	 public EmployeeBuilder employeeemailid(String employeeemailid)
	 {
	 	this.employeeemailid = employeeemailid;
	 	return this;
	 }

	
	 }
	
	
	
	
	 public static EmployeeBuilder builder()
	 {
		 return new EmployeeBuilder();
	 }
	
	
	
	

}
