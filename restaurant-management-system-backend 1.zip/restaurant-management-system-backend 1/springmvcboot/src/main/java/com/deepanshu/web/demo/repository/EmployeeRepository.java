package com.deepanshu.web.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.deepanshu.web.demo.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	
	//public List<Employee> findByEmployeedesgn();
	
	
	@Query("select e from Employee e where e.employeename =:name")
	public List<Employee> getEmpByName(@Param("name") String name);
	
	

}
