package com.deepanshu.web.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deepanshu.web.demo.model.Userinfo;

public interface UserRepository extends JpaRepository<Userinfo, Integer>{

	Optional<Userinfo> findByName(String username);
	
	Userinfo findByEmail(String email);
	
	Userinfo findById(int id);

}
