package com.deepanshu.web.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.deepanshu.web.demo.model.User;
 
@Repository
public interface UseritemRepository extends JpaRepository<User, Long>{
 
}