package com.deepanshu.web.demo.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.deepanshu.web.demo.model.MenuItem;

public interface MenuService {

	public MenuItem createMenu(MenuItem menuItem);
	
	public List<MenuItem> getAllMenu();
	
	public MenuItem getMenuById(int id);
	
	public String updateMenu(int id,MenuItem menuItem);
	
	public String deleteMenu(int id);

	public List<MenuItem> getMenuByName(String name);
	
	
	
}
