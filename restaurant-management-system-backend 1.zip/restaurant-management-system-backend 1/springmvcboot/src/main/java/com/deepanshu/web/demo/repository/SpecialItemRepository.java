package com.deepanshu.web.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deepanshu.web.demo.model.SpecialItem;

public interface SpecialItemRepository extends JpaRepository<SpecialItem, Integer>{

}
