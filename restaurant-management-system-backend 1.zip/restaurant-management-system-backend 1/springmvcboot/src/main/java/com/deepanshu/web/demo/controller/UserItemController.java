package com.deepanshu.web.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.deepanshu.web.demo.model.User;
import com.deepanshu.web.demo.service.UserItemServiec;
 
 
@RestController
@CrossOrigin(origins = "http://localhost:3001")
public class UserItemController {
 
	@Autowired
	private UserItemServiec service;
 
	// Sign Up
	@PostMapping("/post/user")
	public ResponseEntity<User> signUp(@RequestBody User ob) throws Exception {
		User login = service.save(ob);
		return new ResponseEntity<>(login, HttpStatus.CREATED);
	}
 
	// Get all Users
	@GetMapping("/user")
	public ResponseEntity<List<User>> retrieveAllUsers() throws Exception {
		List<User> loginList = service.findAllValues();
		return new ResponseEntity<>(loginList, HttpStatus.OK);
	}
 
	// Get User by id
	@GetMapping("/user/{id}")
	public ResponseEntity<User> retrieveUser(@PathVariable Long id) throws Exception {
		User login = service.findOne(id);
		return new ResponseEntity<>(login, HttpStatus.OK);
	}
 
	// Delete a user id
	@DeleteMapping("/user/{id}")
	public String deleteUser(@PathVariable Long id) throws Exception {
		service.delete(id);
		return "Record removed Successfully";
	}
 
	@PutMapping("/user")
	public ResponseEntity<User> updateUser(@RequestBody User ob) throws Exception {
		User login = service.update(ob);
		return new ResponseEntity<>(login, HttpStatus.OK);
	}
 
	// Log in
	@GetMapping("/user/{email}/{pass}")
	public User logIn(@PathVariable String email, @PathVariable String pass) throws Exception {
		User login = service.logIn(email, pass);
		return login;
	}
 
}