package com.deepanshu.web.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deepanshu.web.demo.model.SpecialItem;
import com.deepanshu.web.demo.service.SpecialItemService;
import com.deepanshu.web.demo.service.SpecialItemServiceImpl;

@RestController
@RequestMapping("/api/specialmenu")
@CrossOrigin(origins = "http://localhost:3001")
public class SpecialItemController {
	
	@Autowired
	private SpecialItemService specialItemService;

	
	@PostMapping("/admin/addmenu")
	public ResponseEntity<SpecialItem> createMenu(@RequestBody SpecialItem specialItem) {
		
		SpecialItem specialItem2=specialItemService.createMenu(specialItem);
		
		return new ResponseEntity<>(specialItem2,HttpStatus.CREATED);
	}
	
	@GetMapping("/getall")
	public ResponseEntity<List<SpecialItem>> getAllSpecialItem(){
		
		List<SpecialItem> listSpecialItem=specialItemService.getAllSpecialItem();
		return new ResponseEntity<>(listSpecialItem,HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<SpecialItem> getSpecialItemById(@PathVariable int id) {
		
		SpecialItem specialItem=specialItemService.getSpecialItemById(id);
		return new ResponseEntity<>(specialItem,HttpStatus.OK);
	}
	
	@PutMapping("/update/{id}")
	public String updateSpecialItem(@PathVariable int id,@RequestBody SpecialItem specialItem) {
		
		return specialItemService.updateSpecialItem(id, specialItem);
	}
	
	
    @DeleteMapping("/delete/{id}")
	public String deleteSpecialItem(@PathVariable int id) {
		
    	return specialItemService.deleteSpecialItem(id);
		
	}
	
	
	
}
