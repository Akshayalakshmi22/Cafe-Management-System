package com.deepanshu.web.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deepanshu.web.demo.model.LoginRequest;
import com.deepanshu.web.demo.model.Userinfo;
import com.deepanshu.web.demo.service.UserService;
import com.deepanshu.web.demo.service.UserServiceImpl;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@CrossOrigin(origins = "http://localhost:3001")
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/adduser")
	public String addNewUser(@RequestBody  Userinfo userinfo)
	{
		return userService.addUser(userinfo);
	}
	
	@GetMapping("/alluser")
	public List<Userinfo> getAllUser()
	{
		return userService.getAllUser();
	}
	
	
	// Register user
    @PostMapping("/user/registration")
	public ResponseEntity<?> saveCustomerDetails(@RequestBody @Valid Userinfo userinfo)
	{
	 
		return new ResponseEntity<>(userService.saveCustomerDetails(userinfo),HttpStatus.CREATED);
		
	}
	
	// login user
	@GetMapping("/user/login")
	public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest)
	{
		String email=loginRequest.getEmail();
		String password=loginRequest.getPassword();
		
		boolean isAuth=userService.login(email, password);
		if(isAuth)
		{
			return ResponseEntity.ok("Login Successfully!!");
		}
		else 
			{
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Username or password is not correct");
			}
		
	}
	
}
