package com.deepanshu.web.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deepanshu.web.demo.customException.ResourceNotFoundException;
import com.deepanshu.web.demo.model.Employee;
import com.deepanshu.web.demo.repository.EmployeeRepository;



@Service
public class EmployeeServiceImpl implements EmployeeService{

	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public Employee AddEmployee(Employee employee) {
		// TODO Auto-generated method stub
	
		
		return employeeRepository.save(employee);
		
	}

	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		
		Employee employee=employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Employee ","id",id));
		
		return employee;
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		
		return employeeRepository.findAll();
	}

	@Override
	public Employee updateEmployee(int id, Employee employee) {
		// TODO Auto-generated method stub
		Employee existingEmployee=employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Employee ","id",id));
		
		existingEmployee.setEmployeename(employee.getEmployeename());
		existingEmployee.setEmployeedesgn(employee.getEmployeedesgn());
		existingEmployee.setEmployeeemailid(employee.getEmployeeemailid());
		existingEmployee.setEmployeephoneno(employee.getEmployeephoneno());
		
		Employee employee2=employeeRepository.save(existingEmployee);
		return employee2;
		
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		
		//Employee deleteEmployee=employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Employee ","id",id));
		
		employeeRepository.deleteById(id);
		
		
	}



}
