package com.deepanshu.web.demo.service;

import java.util.List;


import com.deepanshu.web.demo.model.SpecialItem;

public interface SpecialItemService {
	
	
	public SpecialItem createMenu(SpecialItem specialItem);
	
	public List<SpecialItem> getAllSpecialItem();
	
	public SpecialItem getSpecialItemById(int id);
	
	public String updateSpecialItem(int id,SpecialItem specialItem);
	
	public String deleteSpecialItem(int id);

}
