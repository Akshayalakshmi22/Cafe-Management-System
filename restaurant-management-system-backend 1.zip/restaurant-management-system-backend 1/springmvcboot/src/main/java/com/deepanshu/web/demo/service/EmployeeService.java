package com.deepanshu.web.demo.service;

import java.util.List;

import com.deepanshu.web.demo.model.Employee;

public interface EmployeeService {
	
	
	public Employee AddEmployee(Employee employee);
	
	public Employee getEmployeeById(int id);
	
	public List<Employee> getAllEmployee();
	
	public Employee updateEmployee(int id,Employee employee);
	
	public void deleteEmployee(int id);
	
	//public List<Employee> getEmployeeByDesig();

}
