package com.deepanshu.web.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deepanshu.web.demo.model.Userinfo;
import com.deepanshu.web.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
	private UserRepository userRepository;
	

	
	@Override
	public String addUser(Userinfo userinfo) {
		// TODO Auto-generated method stub
		
		if (userinfo.getPassword() != null) {
			userinfo.setPassword(userinfo.getPassword());
		} else {
		    throw new IllegalArgumentException("Password cannot be null");
		}
  
		userRepository.save(userinfo);
		return "User added Successfully!!";
	}

	@Override
	public List<Userinfo> getAllUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}
    
	// Registered
	@Override
	public String saveCustomerDetails(Userinfo userinfo) {
		
		Userinfo customerDetails = userRepository.save(userinfo); 
		
		return customerDetails.getName() + ", you have successfully registred as : " + customerDetails.getEmail();
		
	}
    
	// Login 
	@Override
	public boolean login(String email, String password) {
		// TODO Auto-generated method stub
		
		Userinfo userinfo=userRepository.findByEmail(email);
		return userinfo!=null && userinfo.getPassword().equals(password);
	}

}
