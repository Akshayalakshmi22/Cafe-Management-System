package com.deepanshu.web.demo.service;

import java.util.List;

import com.deepanshu.web.demo.model.Userinfo;

public interface UserService {

	public String addUser(Userinfo userinfo);
	
	public List<Userinfo> getAllUser();
	
	//Registration
	public String saveCustomerDetails(Userinfo userinfo);
	
	//login
	public boolean login(String email, String password);
	
}
