package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.customException.ResourceNotFoundException;
import com.cts.model.MenuItem;
import com.cts.repository.MenuItemRepository;


@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	private MenuItemRepository menuItemRepository;
	
	@Override
	public MenuItem createMenu(MenuItem menuItem) {
		// TODO Auto-generated method stub	
		return menuItemRepository.save(menuItem);	
	}

	@Override
	public List<MenuItem> getAllMenu() {
		// TODO Auto-generated method stub		
		return menuItemRepository.findAll();
	}

	@Override
	public MenuItem getMenuById(int id) {
		// TODO Auto-generated method stub
		MenuItem menuItem=menuItemRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Menu ", "id", id));	
		return menuItem;
	}

	@Override
	public String updateMenu(int id, MenuItem menuItem) {
		// TODO Auto-generated method stub
		MenuItem existinfmenuItem=getMenuById(id);	
		existinfmenuItem.setItemname(menuItem.getItemname());	
		existinfmenuItem.setItemtype(menuItem.getItemtype());
		existinfmenuItem.setPrice(menuItem.getPrice());		
		menuItemRepository.save(existinfmenuItem);
		return "Menu added successfully!!";
	}

	@Override
	public String deleteMenu(int id) {
		// TODO Auto-generated method stub
		MenuItem menuItem=menuItemRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Menu ", "id", id));
		menuItemRepository.deleteById(id);
		return "Menu deleted successfully!!";
	}

	@Override
	public List<MenuItem> getMenuByName(String name) {
		// TODO Auto-generated method stub
		return menuItemRepository.getMenuByName(name);	
	}
}
