package com.cts.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
 
@Entity
@Table(name="specialitems")
public class SpecialItem {
 
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemid;
	private String itemname;
	private String itemtype;

	private int price;
	private String dayofweek;
 
	public int getItemid() {
		return itemid;
	}
 
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
 
	public String getItemname() {
		return itemname;
	}
 
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
 
	public String getItemtype() {
		return itemtype;
	}
 
	public void setItemtype(String itemtype) {
		this.itemtype = itemtype;
	}
 
	public int getPrice() {
		return price;
	}
 
	public void setPrice(int price) {
		this.price = price;
	}
 
	public String getDayofweek() {
		return dayofweek;
	}
 
	public void setDayofweek(String dayofweek) {
		this.dayofweek = dayofweek;
	}
 
	public SpecialItem(int itemid, String itemname, String itemtype, int price, String dayofweek) {
		super();
		this.itemid = itemid;
		this.itemname = itemname;
		this.itemtype = itemtype;
		this.price = price;
		this.dayofweek = dayofweek;
	}
 
	public SpecialItem() {
		super();
		// TODO Auto-generated constructor stub
	}
 
 
	
 
	
}