package com.cts.service;

import java.util.List;
import com.cts.model.MenuItem;

public interface MenuService {

	public MenuItem createMenu(MenuItem menuItem);
	
	public List<MenuItem> getAllMenu();
	
	public MenuItem getMenuById(int id);
	
	public String updateMenu(int id,MenuItem menuItem);
	
	public String deleteMenu(int id);

	public List<MenuItem> getMenuByName(String name);	
}
