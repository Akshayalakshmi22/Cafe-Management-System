package com.cts.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.cts.customException.ResourceNotFoundException;
import com.cts.model.SpecialItem;
import com.cts.repository.SpecialItemRepository;
 
@Service
public class SpecialItemServiceImpl implements SpecialItemService{
 
	@Autowired
	private SpecialItemRepository specialItemRepository;
	@Override
	public SpecialItem createMenu(SpecialItem specialItem) {
		// TODO Auto-generated method stub

		return specialItemRepository.save(specialItem);
	}
 
	@Override
	public List<SpecialItem> getAllSpecialItem() {
		// TODO Auto-generated method stub

		return specialItemRepository.findAll();
	}
 
	@Override
	public SpecialItem getSpecialItemById(int id) {
		// TODO Auto-generated method stub
		SpecialItem specialItem=specialItemRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("SpecialMenu ", "id", id));
		return specialItem;
	}
 
	@Override
	public String updateSpecialItem(int id, SpecialItem specialItem) {
		// TODO Auto-generated method stub
		SpecialItem ExistingspecialItem=getSpecialItemById(id);
		ExistingspecialItem.setItemname(specialItem.getItemname());
		ExistingspecialItem.setItemtype(specialItem.getItemtype());
		ExistingspecialItem.setPrice(specialItem.getPrice());
		ExistingspecialItem.setDayofweek(specialItem.getDayofweek());
		specialItemRepository.save(ExistingspecialItem);

		return "Update menu successfully!!";
	}
 
	@Override
	public String deleteSpecialItem(int id) {
		// TODO Auto-generated method stub
		SpecialItem specialItem=specialItemRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("SpecialMenu ", "id", id));
		specialItemRepository.delete(specialItem);

		return "Menu deleted successfully!!";
	}
 
}