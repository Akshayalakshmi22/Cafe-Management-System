package com.cts.service;

import java.util.List;

import com.cts.model.User;

public interface UserService {
	
	public List<User> findAllValues() throws Exception;
	public User findOne(Long id) throws Exception;
	public User save(User ob) throws Exception;
	public String delete(Long idd) throws Exception;
	public User update(User ob) throws Exception;
	public User logIn(String email, String pass) throws Exception;
	
	
}
