import React, { useEffect, useState } from 'react'
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { toast } from 'react-toastify';

export default function Home() {

 const [employee,setemployee]=useState([]);

 // check user is Admin or not
 const userString = localStorage.getItem("user");
 let user = {};

 if (userString) {
   user = JSON.parse(userString);
 }
 const isAdmin = user.role === 'Admin';

 // Useparam for get the id
 const {id}=useParams()

 
 useEffect(()=>{
  toast.success("Data fetch successfully!!");
loademployee();
 },[]);

const loademployee=async()=>{
    const result=await axios.get("http://localhost:1500/api/admin/getall");
    setemployee(result.data);
};

if(isAdmin)
{
// For Delete Employee
const deleteUser=async(id)=>{
  await axios.delete(`http://localhost:1500/api/admin/delete/${id}`);
  loademployee();
}



  return (
    <div className="container">
        <div className="py-4">
        <h2 className="text-center m-4">All Employees </h2> 
        <table className="table border shadow">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Name</th>
      <th scope="col">Designation</th>
      <th scope="col">Phone-No</th>
      <th scope="col">Email-Id</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    {
        employee.map((emp,index)=>{
         return(
            <tr>
            <th scope="row" key={index}>{index+1}</th>
            <td>{emp.employeename}</td>
            <td>{emp.employeedesgn}</td>
            <td>{emp.employeephoneno}</td>
            <td>{emp.employeeemailid}</td>
            <td>
                
                <Link className="btn btn-warning mx-2"
                to={`/edituser/${emp.id}`}
                >Edit</Link>
                <button className="btn btn-danger mx-2"
                onClick={()=>deleteUser(emp.id)}
                >Delete</button>
            </td>
          </tr>
         )
        })
    }

  </tbody>
</table>
        </div>
    </div>
  )
}else{
  return <p style={{textAlign:"center"}}>This page only accessed by Admin</p>
}

}