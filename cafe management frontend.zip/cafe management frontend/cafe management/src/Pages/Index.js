import React from 'react'

export default function Index() {
  return (
    <div>
      <div
        className="bg-image d-flex justify-content-center align-items-center flex-column"
        style={{
          backgroundImage: "url('https://img.freepik.com/premium-photo/rich-espresso-shot_1040335-49227.jpg?w=1060')",
          backgroundRepeat: "no-repeat",
          height: "100vh",
          backgroundSize: "cover"
        }}
      >
        <div>
          <h1 className="text-white" style={{fontSize: 100, fontFamily: "Times New Roman"}}>Aura</h1>
        </div>
        <div>
          <h4 className="text-white" style={{fontSize: 40, fontFamily: "Times New Roman"}}>The Cafe Management System</h4>
        </div>
      </div>
    </div>
  )
}