import React from 'react'
import './About.css';


export default function About() {
  return (
    <div>
      <div class="we-are-block">

        <div id="about-us-section">

          <div class="about-us-image">

            <img src="https://img.freepik.com/free-photo/view-professional-handshake-business-people_23-2150917092.jpg?t=st=1714625699~exp=1714629299~hmac=15ac20569a71292158bb6dab93a76d37c4f8ce2905495b74f56da4c67d84a852&w=740" width="808" height="458" alt="Lobby Image"  />

          </div>

          <div class="about-us-info">

            <h2>We are Aura</h2>

            <p>Aura is a system for managing cafes, crafted to optimize your business procedures and enhance the experience of your customers.With Aura, you are in good hands.</p>

            <a href="#" title="About Us Button">ABOUT US</a>

          </div>

        </div>

        <div id="history-section">

          <div class="history-image">

            <img src="https://img.freepik.com/free-photo/abstract-computer-chip-metal-binary-code-security-generated-by-ai_188544-20344.jpg?t=st=1714627785~exp=1714631385~hmac=6ca482dc9cb6150a6c03bb9e5bd5fd81f357caab9b2ef9188a4ba5e3ef989d82&w=1060" width="951" height="471" alt="History Pic" />

          </div>

          <div class="history-info">

            <h2>Preserving Local History</h2>

            <p>In 2018, technology companies, Desktop Doctors & Digital Upgrade found a new place to call home, at 816 N. 9th Ave. Since the takeover of the 118-year-old building (formally Stippler Tool & Supply and Crown Chair Company), there have been many renovations completed to preserve this local piece of Evansville, IN history.</p>

            <a href="#" title="History Button">HISTORY</a>

          </div>

        </div>

      </div>
    </div>
  )
}
