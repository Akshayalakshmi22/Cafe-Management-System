import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import "./Login.css";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.get(`http://localhost:1500/user/${email}/${password}`)
      .then((res) => {
        localStorage.setItem("user",JSON.stringify(res.data));
        console.log(res);

        console.log(res.data);
        localStorage.setItem("user", JSON.stringify(res.data));

        alert("Successful");
        navigate("/");
      })
      .catch((error) => {
        alert('There was an error!', error);
      });
  }

  return (
    <div>
      <h1>Login</h1>
      <div className='login'>
        <form onSubmit={handleSubmit}>
          <div className="input">
            <label htmlFor="email">Email:</label>
            <input type="email" id="email" value={email} onChange={(event) => setEmail(event.target.value)} required /></div>
          <div className="input">
            <label htmlFor="password">Password:</label>
            <input type="password" id="password" value={password} onChange={(event) => setPassword(event.target.value)} required />
          </div>
          <p>New User? <span onClick={() => navigate('/signup')} style={{color: 'blue', cursor: 'pointer'}}>Click here for Registration</span></p>
          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
}

export default Login;