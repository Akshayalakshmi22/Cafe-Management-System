import axios from 'axios';
import React, { useState } from 'react'
import { Link, useNavigate } from "react-router-dom";

export default function Addemployee() {
    let navigate=useNavigate()

    const userString = localStorage.getItem("user");
    let user = {};
   
    if (userString) {
      user = JSON.parse(userString);
    }
    const isAdmin = user.role === 'Admin';

    const [employee,setEmployee]=useState({
         employeename:"",
        employeedesgn:"",
        employeephoneno:"",
        employeeemailid:""
    })

const{employeename,employeedesgn,employeephoneno,employeeemailid}=employee

 const onInputChange=(e)=>{
     setEmployee({...employee,[e.target.name]:e.target.value});
 };

 if(isAdmin)
 {
  const onSubmit=async (e)=>{
    e.preventDefault();
    await axios.post("http://localhost:1500/api/admin/addEmployee",employee);
    navigate("/home");
 };

  return (
    <div className="container"
    style={{
      backgroundImage: "url('https://img.freepik.com/premium-photo/mature-grey-haired-woman-using-bank-credit-card-online-payment-laptop-from-home-office_266732-30886.jpg?w=900')",
      backgroundRepeat: "no-repeat",
      height: "100vh",
      backgroundSize: "cover"
    }}>
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4 text-white">Add Employee</h2>

          <form onSubmit={(e)=>onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="Name" className="form-label">
                Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter your name"
                name="employeename"
                value={employeename}
                onChange={(e)=>onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Username" className="form-label">
                Employee Designation
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter your Designation"
                name="employeedesgn"  
                value={employeedesgn}
                onChange={(e)=>onInputChange(e)}              
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                Phone-no
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter your Phone-no"
                name="employeephoneno"
                value={employeephoneno}
                onChange={(e)=>onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                E-mail
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter your e-mail address"
                name="employeeemailid"
                value={employeeemailid}
                onChange={(e)=>onInputChange(e)}
              />
            </div>
            <button type="submit" className="btn btn-outline-primary">
              Submit
            </button>
            <Link className="btn btn-outline-danger mx-2" to="/">
              Cancel
            </Link>
          </form>
        </div>
      </div>
    </div>
  )
 }
 else{
   return <p style={{textAlign:"center"}}>This page only accessed by Admin</p>
 }
}