import React, { useState } from "react";
import "./SearchMenu.css";

const SearchMenu = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [menuItems, setMenuItems] = useState([]);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // call API endpoint to search menu items by name
    fetch(`http://localhost:1500/api/menu/searchmenu?name=${searchTerm}`)
      .then((res) => res.json())
      .then((data) => setMenuItems(data));
  };

  return (
    <div className="search-menu-container"
    style={{
      backgroundImage: "url('https://img.freepik.com/free-photo/coffee-cup_1339-4975.jpg?t=st=1714639699~exp=1714643299~hmac=deee778370db6645442dd9577adc5c20d949d76a893d108648b0784c4833e5ec&w=900')",
      backgroundRepeat: "no-repeat",
      height: "100vh",
      backgroundSize: "cover"
    }}>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Search menu items..."
          value={searchTerm}
          onChange={handleSearch}
        />
        <button type="submit">Search</button>
      </form>
      <table>
        <thead>
          <tr>
            <th>Item ID</th>
            <th>Item Name</th>
            <th>Item Type</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {menuItems.map((item) => (
            <tr key={item.itemid}>
              <td>{item.itemid}</td>
              <td>{item.itemname}</td>
              <td>{item.itemtype}</td>
              <td>{item.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SearchMenu;