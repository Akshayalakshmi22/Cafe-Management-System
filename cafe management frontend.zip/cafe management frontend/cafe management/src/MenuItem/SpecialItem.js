import axios from 'axios';
import React, { useState } from 'react'
import { Link, useNavigate } from "react-router-dom";
export default function SpecialItem() {
    let navigate=useNavigate()
   
    // check user is Admin or not
    const userString = localStorage.getItem("user");
    let user = {};
   
    if (userString) {
      user = JSON.parse(userString);
    }
    const isAdmin = user.role === 'Admin';
 
    const [Menu,setMenu]=useState({
        itemname:"",
        itemtype:"",
        price:"",
        dayofweek:""
 
    })
 
const{itemname,itemtype,price,dayofweek}=Menu
 
 const onInputChange=(e)=>{
    setMenu({...Menu,[e.target.name]:e.target.value});
 };
 
 if(isAdmin)
 {
  const onSubmit=async (e)=>{
    e.preventDefault();
    await axios.post("http://localhost:1500/api/specialmenu/admin/addmenu",Menu);
    navigate("/show-specialfood");
 };
 
  return (
    <div className="container"
    style={{
      backgroundImage: "url('https://img.freepik.com/premium-photo/delicate-cup-coffee-is-placed-wooden-table-with-delicious-sandwich-it_1082068-81526.jpg?w=1060')",
      backgroundRepeat: "no-repeat",
      height: "100vh",
      backgroundSize: "cover"
    }}>
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4 text-white">Add Special Menu Item</h2>
 
          <form onSubmit={(e)=>onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="Name" className="form-label">
                Menu Item Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Item Name"
                name="itemname"
                value={itemname}
                onChange={(e)=>onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Username" className="form-label">
                Menu Item Type
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Menu Item Type"
                name="itemtype"  
                value={itemtype}
                onChange={(e)=>onInputChange(e)}              
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                Price
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter the Price"
                name="price"
                value={price}
                onChange={(e)=>onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                Day Of Week
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter the Day of Week"
                name="dayofweek"
                value={dayofweek}
                onChange={(e)=>onInputChange(e)}
              />
            </div>
            <button type="submit" className="btn btn-outline-primary">
              Submit
            </button>
            <Link className="btn btn-outline-danger mx-2" to="/">
              Cancel
            </Link>
          </form>
        </div>
      </div>
    </div>
  )
 }else{
  return <p style={{textAlign:"center"}}>This page only accessed by Admin</p>
 }
}