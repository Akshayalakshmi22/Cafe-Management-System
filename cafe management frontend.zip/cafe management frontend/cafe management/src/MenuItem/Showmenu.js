import React, { useEffect, useState } from 'react'
import axios from "axios";
import { Link, useParams } from 'react-router-dom';

export default function Showmenu() {
  
  const userString = localStorage.getItem("user");
  let user = {};
 
  if (userString) {
    user = JSON.parse(userString);
  }
  const isAdmin = user.role === 'Admin';
 
 
  const [menu, setMenu] = useState([]);
 
  const { id } = useParams();
 
  useEffect(() => {
    loadMenu();
  }, []);
 
  const loadMenu = async () => {
    const result = await axios.get("http://localhost:1500/api/menu/getallmenu");
    setMenu(result.data);
  }
  
  const deleteMenu = async (id) => {
    if (isAdmin) {
      await axios.delete(`http://localhost:1500/api/menu/delete/${id}`);
      loadMenu();
    }
    else {
      alert("Only Admin can Access!");
    }
  }
 
 
  return (
    <div className="container" 
    style={{
      backgroundImage: "url('https://img.freepik.com/free-photo/delicious-coffee-cups-with-plants_23-2150708034.jpg?t=st=1714641409~exp=1714645009~hmac=c2bccd22fb69a7f5825f679a369a152331f9b4353565ceb127b113e285c11a3c&w=900')",
      backgroundRepeat: "no-repeat",
      height: "100vh",
      backgroundSize: "cover"
    }}>
      <div className="py-4">
        <h2 className="text-center m-4" style={{ color: "white" }}> Menu </h2>
        <table className="table border shadow table table-light table-striped table-hover">
          <thead>
            <tr>
              <th scope="col">No</th>
              <th scope="col">Item Name</th>
              <th scope="col">Item Type</th>
              <th scope="col">Price</th>
              <th scope="col">
              {isAdmin && (<>
                Actions
                </>)}
                </th>
 
             
            </tr>
          </thead>
          <tbody>
            {/* map will take the data and it will show one by one */}
            {
              menu.map((menu, index) => {
                return (
                  <tr>
                    <th scope="row" key={index}>{index + 1}</th>
                    <td>{menu.itemname}</td>
                    <td>{menu.itemtype}</td>
                    <td>{menu.price}</td>
                    <td>
                      {isAdmin && (<>
 
                        <Link className="btn btn-warning mx-2"
                          to={`/editmenu/${menu.itemid}`}
                        >Edit</Link>
                        <button className="btn btn-danger mx-2"
                          onClick={() => deleteMenu(menu.itemid)}
                        >Delete</button>
                      </>)}
 
                    </td>
                  </tr>
                )
              })
            }
 
          </tbody>
        </table>
      </div>
    </div>
  )
}