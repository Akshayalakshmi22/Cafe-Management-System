import './App.css';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Home from './Pages/Home';
import Index from './Pages/Index';
import Footer from './Pages/Footer';
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import Addemployee from './Employee/Addemployee';
import SearchFood from './MenuItem/Searchfood';
import Contact from './Pages/Contact';
import AddMenu from './MenuItem/AddMenu';
import SpecialItem from './MenuItem/SpecialItem';
import Showmenu from './MenuItem/Showmenu';
import Showspecialmenu from './MenuItem/Showspecialfood';
import Editemployee from './Employee/EditUser';
import EditMenu from './MenuItem/Editmenu';
import EditSpecialItem from './MenuItem/EditSpecialItem';
import About from './Pages/About';
import Userpage from './UserComponent/NavUser';
import Login from './Auth/Login';
import Signup from './Auth/Signup';
import PrivateRoute from './Layout/PrivateRoute';
import { useNavigate } from "react-router-dom";
import { useEffect } from 'react';


import Logout from './Auth/Logout';


function App() {


  return (
    <div>
      <Router>
      <PrivateRoute />
        <Routes> 
          <Route exact path="/" element={<Index/>} />
          <Route exact path="/home" element={<Home />} />
          <Route exact path="/add-employee" element={<Addemployee/>} />
          <Route exact path="/add-menu" element={<AddMenu/>} />
          <Route exact path="/add-specialitem" element={<SpecialItem/>} />
          <Route exact path="/search-food" element={<SearchFood/>} />
          <Route exact path="/show-menu" element={<Showmenu/>} />
          <Route exact path="/show-specialfood" element={<Showspecialmenu/>} />
          <Route exact path="/edituser/:id" element={<Editemployee/>} />
          <Route exact path="/editmenu/:id" element={<EditMenu/>} />
          <Route exact path="/editspecialitem/:id" element={<EditSpecialItem/>} />
          <Route exact path="/AddspecialItem" element={<SpecialItem/>} />
          <Route exact path="/contact" element={<Contact/>} />
          <Route exact path="/about" element={<About/>} />
          <Route exact path="/userpage" element={<Userpage/>} />
          <Route exact path ="/signup" element={<Signup/>}/>
           <Route exact path ="/login" element={<Login/>}/> 
           <Route exact path ="/logout" element={<Logout/>}/> 
        </Routes>
        <Footer />
      </Router>
    </div>
  );
}

export default App;
