import { useLocation } from 'react-router-dom';
import Navbar from './Navbar';

function PrivateRoute() {
  const location = useLocation();

  // Check if the current location matches the login or signup routes
  if (location.pathname === '/login' || location.pathname === '/signup') {
    return null;
  }

  // If the user is logged in, show the Navbar
  return <Navbar />;
}

export default PrivateRoute;