import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {

    // check user is Admin or not
    const userString = localStorage.getItem("user");
    let user = {};

    if (userString) {
        user = JSON.parse(userString);
    }
    const isAdmin = user.role === 'Admin';


    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-dark bg-secondary">
                <Link className="navbar-brand" to="/">Aura</Link>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">
                        <li className="nav-item active">
                            <Link className="nav-link" to="/">Home</Link>
                        </li> 
                        {isAdmin && (<>
                            <li className="nav-item">
                                <Link className="nav-link" to="/add-employee">Add Employee</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/add-menu">Add Menu</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/home">Show Employees</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/AddspecialItem">Add Special Item</Link>
                            </li>

                        </>)}

                        <li className="nav-item">
                            <Link className="nav-link" to="/search-food">Search Food</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/show-menu">Show Menu</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/show-specialfood">Show Special Item</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/contact" tabIndex="-1" aria-disabled="true">Contact</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/about" tabIndex="-1" aria-disabled="true">About Us</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/logout" tabIndex="-1" aria-disabled="true">Logout</Link>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    )
}